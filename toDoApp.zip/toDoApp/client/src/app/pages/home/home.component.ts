import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  toDos = [
    {
      name  : 'Todo 1',
      about :  'This is tets demo about for todo 1'
    },
    {
      name  : 'Todo 2',
      about :  'This is tets demo about for todo 2'
    },
    {
      name  : 'Todo 3',
      about :  'This is tets demo about for todo 3'
    },
    {
      name  : 'Todo 4',
      about :  'This is tets demo about for todo 4'
    }
  ]
  constructor() { }

  ngOnInit(): void {
  }
  
  delete(i:number) {
    alert(i);
  }
}
