import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  toDos = [
    {
      name  : 'Todo 1',
      about :  'This is tets demo about for todo 1'
    },
    {
      name  : 'Todo 2',
      about :  'This is tets demo about for todo 2'
    },
    {
      name  : 'Todo 3',
      about :  'This is tets demo about for todo 3'
    },
    {
      name  : 'Todo 4',
      about :  'This is tets demo about for todo 4'
    }
  ]
  editForm:FormGroup;
  
  constructor(
    private fb:FormBuilder,
    private activatedRoute: ActivatedRoute
    ) { 
    this.editForm = this.fb.group({
      'name': [''],
      'about': [''],
      'date' : ['']
    })
  }
  ngOnInit(): void {
    this.getData();
  }

  getData() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    const currentIndex =  parseInt(id == null ? '0': id);
    this.editForm.get('name')?.setValue(this.toDos[currentIndex].name) 
    this.editForm.get('about')?.setValue(this.toDos[currentIndex].about) 
  }
  update() {

  }

}
