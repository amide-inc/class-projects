import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navabr',
  templateUrl: './navabr.component.html',
  styleUrls: ['./navabr.component.css']
})
export class NavabrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
