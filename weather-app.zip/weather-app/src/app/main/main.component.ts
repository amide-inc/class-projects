import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  city_name ="New Delhi";
  data:any;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.getWeather();
  }

  getWeather() {
    var baseUrl = "https://api.openweathermap.org/data/2.5/weather?q="+this.city_name+"&appid=b326d0250896b8840d30cb1bdd5fcf80";
    this.http.get(baseUrl)
        .subscribe(
          res => {
            this.data =  res;
          },
          err => {
            alert("error")
          }
          )
  }

}
